/* ============================================================
   Akashic EIS — docdrawer.js
   Universal embedded document drawer.
   Usage: AKDocs.openFor({ entityType, entityId, entityName })
   Any entity screen can call this. Injects a right-side drawer
   with: doc list for entity, upload zone, extraction overlay,
   annotation/comment thread, cross-link chips, validate & approve.
   ============================================================ */
(function () {
  let _open = false;

  /* ---- Sample extraction data ---- */
  const EXTRACTIONS = {
    D01: [
      { field:'Contract expiry',    val:'22 Jun 2026', conf:.71, clause:'§2.1 Term', page:11, validated:false },
      { field:'Auto-renewal',       val:'No',          conf:.68, clause:'§2.3',      page:12, validated:false },
      { field:'Governing law',      val:'Delaware, USA', conf:.88, clause:'§17',     page:16, validated:true,  by:'K. Iyer' },
    ],
    D02: [
      { field:'SOW value',          val:'₹9.6 Cr',     conf:.99, clause:'§4 Fees',  page:5,  validated:true,  by:'R. Desai' },
      { field:'Go-live date',       val:'30 Sep 2026',  conf:.92, clause:'§3',       page:3,  validated:true,  by:'R. Desai' },
    ],
    D03: [
      { field:'Annual fee',         val:'₹4.1 Cr',     conf:.84, clause:'§4',       page:5,  validated:false },
      { field:'Escalation %',       val:'5% p.a.',      conf:.79, clause:'§4.2',     page:5,  validated:false },
    ],
    D07: [
      { field:'SLA uptime target',  val:'99.5%',        conf:.73, clause:'§6.2',     page:8,  validated:false },
      { field:'Penalty clause',     val:'Schedule C',   conf:.68, clause:'§6.3',     page:9,  validated:false },
    ],
  };

  const COMMENTS = {
    D01: [
      { user:'K. Iyer', time:'2 days ago', text:'Conf is 0.71 on expiry — needs manual check against original PDF signed copy.' },
      { user:'R. Desai', time:'1 day ago', text:'Confirmed with legal. Expiry is definitely 22 Jun 2026.' },
    ],
  };

  function getDocsForEntity(entityType, entityId) {
    if (!window.AKData) return [];
    if (entityType === 'client')  return AKData.documentsByClient(entityId);
    if (entityType === 'project') return AKData.documentsByProject(entityId);
    return AKData.documents.filter(d => d.clientId === entityId || d.projectId === entityId);
  }

  function confChip(conf, validated, by) {
    if (validated) return `<span class="conf verified">✓ ${by||'validated'}</span>`;
    if (conf === null) return `<span class="conf lo">processing</span>`;
    const lvl = conf >= .9 ? 'hi' : conf >= .8 ? 'md' : 'lo';
    return `<span class="conf ${lvl}"><span class="cbar"><i style="width:${conf*100}%"></i></span>${conf.toFixed(2)}</span>`;
  }

  function docIcon(type) {
    const icons = { MSA:'📄', SOW:'📋', Addendum:'🔗', MoM:'📝', Email:'✉', default:'📁' };
    return icons[type] || icons.default;
  }

  function buildDrawer(entityType, entityId, entityName) {
    const docs = getDocsForEntity(entityType, entityId);
    const pendingCount = docs.filter(d => !d.validated && d.ingested && d.conf !== null && d.conf < .9).length;
    return `
<div id="ak-doc-drawer" class="dd-overlay">
  <div class="dd-drawer">
    <div class="dd-head">
      <div>
        <div class="dd-eyebrow">${entityType} · ${entityName}</div>
        <div class="dd-title">Documents</div>
      </div>
      <div class="flex items-center gap-8">
        ${pendingCount > 0 ? `<span class="badge b-renewal"><span class="bd"></span>${pendingCount} need validation</span>` : ''}
        <button class="btn sm primary" onclick="AKDocs.triggerUpload('${entityId}')">+ Ingest document</button>
        <button class="btn xs ghost" onclick="AKDocs.close()">✕ Close</button>
      </div>
    </div>

    <!-- UPLOAD ZONE -->
    <div class="dd-upload" id="dd-upload-${entityId}" ondragover="event.preventDefault();this.classList.add('drag')" ondragleave="this.classList.remove('drag')" ondrop="AKDocs.handleDrop(event,'${entityId}','${entityName}')">
      <div class="dd-upload-inner">
        <span style="font-size:22px">⤵</span>
        <span class="fs-13 strong">Drag &amp; drop to ingest</span>
        <span class="fs-12 muted">PDF · DOCX · EML · XLSX — Akashic extracts fields automatically</span>
      </div>
    </div>

    <!-- DOC LIST -->
    <div class="dd-list">
      ${docs.length === 0 ? '<div class="dd-empty">No documents yet for this entity. Drag &amp; drop above to ingest the first one.</div>' : ''}
      ${docs.map(d => buildDocRow(d, entityId, entityName)).join('')}
    </div>

    <!-- LINKED FROM -->
    <div class="dd-linked">
      <div class="dd-section-l">Cross-linked documents from related entities</div>
      <div class="flex gap-8 flex-wrap mt-8">
        <span class="badge b-accent" style="cursor:pointer" onclick="AK&&AK.toast('Opening cross-linked document')">📄 Orion SOW ← Project P01</span>
        <span class="badge b-accent" style="cursor:pointer" onclick="AK&&AK.toast('Opening QBR MoM')">📝 QBR Apr 26 ← Client C01</span>
        <button class="btn xs ghost" onclick="AKDocs.addCrossLink('${entityId}')">+ Link another document</button>
      </div>
    </div>
  </div>
</div>`;
  }

  function buildDocRow(d, entityId, entityName) {
    const ext = EXTRACTIONS[d.id] || [];
    const pending = ext.filter(e => !e.validated).length;
    return `
<div class="dd-doc-row" id="ddrow-${d.id}">
  <div class="dd-doc-main" onclick="AKDocs.openExtraction('${d.id}','${entityId}','${entityName}')">
    <span class="dd-doc-ico">${docIcon(d.type)}</span>
    <div style="flex:1;min-width:0">
      <div class="dd-doc-name">${d.name}</div>
      <div class="dd-doc-meta">${d.type} · ${d.ingested ? '✓ Ingested' : '⏳ Processing'} · ${ext.length} fields extracted</div>
    </div>
    <div class="flex items-center gap-8">${confChip(d.conf, d.validated, null)}</div>
  </div>
  <div class="dd-doc-actions">
    <button class="btn xs" onclick="AKDocs.openExtraction('${d.id}','${entityId}','${entityName}')">View &amp; validate</button>
    <button class="btn xs" onclick="AK&&AK.toast('Annotation added to ${d.name}')">Annotate</button>
    <button class="btn xs" onclick="AK&&AK.toast('${d.name} downloaded')">Download</button>
    ${pending > 0 ? `<span class="badge b-renewal" style="font-size:10px"><span class="bd"></span>${pending} fields pending</span>` : ''}
  </div>
</div>`;
  }

  function buildExtractionOverlay(docId, entityId, entityName) {
    const d = (window.AKData ? AKData.documents.find(x => x.id === docId) : null) || { name: docId, type: '—' };
    const extractions = EXTRACTIONS[docId] || [];
    const comments = COMMENTS[docId] || [];
    const fieldRows = extractions.map((f, i) => {
      const lvl = f.validated ? 'verified' : f.conf >= .9 ? 'hi' : f.conf >= .8 ? 'md' : 'lo';
      return `<div class="ext-row ${f.validated ? 'validated' : ''}">
        <div class="ext-field">${f.field}</div>
        <input class="ext-input" value="${f.val}" ${f.validated ? 'readonly' : ''} />
        <span class="conf ${lvl}">${f.validated ? `✓ ${f.by}` : `<span class="cbar"><i style="width:${f.conf*100}%"></i></span>${f.conf.toFixed(2)}`}</span>
        <span class="ext-src mono">p.${f.page} · ${f.clause}</span>
        ${!f.validated ? `<button class="btn xs primary" onclick="AKDocs.validateField('${docId}',${i})">Confirm</button>` : ''}
      </div>`;
    }).join('');
    const commentRows = comments.map(c => `<div class="cmt-row"><b>${c.user}</b> <span class="faint">${c.time}</span><div>${c.text}</div></div>`).join('');
    return `
<div id="ak-ext-overlay" class="ext-overlay">
  <div class="ext-modal">
    <div class="ext-head">
      <div><div class="dd-eyebrow">${d.type} · ${entityName}</div><div class="dd-title">${d.name}</div></div>
      <button class="pv-close" onclick="document.getElementById('ak-ext-overlay').remove()" style="font-size:16px;padding:4px 8px">✕</button>
    </div>
    <div class="ext-body">
      <div class="ext-pdf-col">
        <div class="pdf-toolbar"><span class="mono fs-11">${d.name}</span><span class="mono fs-11 faint">Showing extracted clause</span></div>
        <div class="pdf-pane">
          <div class="pdf-line">This Master Services Agreement (MSA) is entered into by and between Nexora Technologies Pvt. Ltd. and Meridian Retail Group Inc.</div>
          <div class="pdf-line mt-8"><b>§2.1 Term.</b> The initial term shall commence on the Effective Date and continue for <span class="clause-hl target">eighty-four (84) months</span>, expiring on <span class="clause-hl target">22 June 2026</span> unless terminated in accordance with §11.</div>
          <div class="pdf-line mt-8">Renewal shall be subject to mutual written agreement; <span class="clause-hl">automatic renewal does not apply</span> to this Agreement.</div>
          <div class="pdf-line mt-8">§2.3 Each party may terminate this Agreement upon ninety (90) days' written notice to the other party.</div>
        </div>
      </div>
      <div class="ext-fields-col">
        <div class="section-label">Extracted fields · confirm or override</div>
        <div class="col gap-8">${fieldRows || '<div class="muted fs-13">No fields extracted for this document.</div>'}</div>
        <div class="divider"></div>
        <div class="section-label">Annotations &amp; comments</div>
        <div class="col gap-8 mb-12">${commentRows || '<div class="muted fs-13">No comments yet.</div>'}</div>
        <div class="flex gap-8"><input class="cmt-input" placeholder="Add annotation or @mention…" /><button class="btn sm" onclick="AK&&AK.toast('Comment added')">Post</button></div>
        <div class="divider"></div>
        <div class="section-label">Propagation</div>
        <div class="prop-chip">${AK&&AK.icon?AK.icon('workflow'):''} Validated fields → Client 360 → Lifecycle, Intelligence Feed</div>
        <div class="fs-12 muted mt-6">Changes are audited · attributed to you · reversible</div>
      </div>
    </div>
  </div>
</div>`;
  }

  function injectStyles() {
    if (document.getElementById('dd-styles')) return;
    const s = document.createElement('style');
    s.id = 'dd-styles';
    s.textContent = `
.dd-overlay{position:fixed;inset:0;background:oklch(0.2 0.01 265 / 0.3);z-index:400;display:flex;justify-content:flex-end}
.dd-drawer{width:540px;max-width:96vw;background:var(--surface);height:100%;display:flex;flex-direction:column;box-shadow:var(--shadow-lg);overflow:hidden;animation:ddIn .18s ease}
@keyframes ddIn{from{transform:translateX(30px);opacity:0}to{transform:none;opacity:1}}
.dd-head{display:flex;align-items:flex-start;justify-content:space-between;padding:18px 18px 14px;border-bottom:1px solid var(--line);flex-wrap:wrap;gap:8px;flex:0 0 auto}
.dd-eyebrow{font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:var(--accent-2);font-weight:700;font-family:var(--mono);margin-bottom:3px}
.dd-title{font-size:18px;font-weight:800}
.dd-upload{border:2px dashed var(--line-2);border-radius:var(--r-lg);margin:14px;padding:18px;text-align:center;cursor:pointer;transition:border-color .12s,background .12s;flex:0 0 auto}
.dd-upload:hover,.dd-upload.drag{border-color:var(--accent);background:var(--accent-soft)}
.dd-upload-inner{display:flex;flex-direction:column;align-items:center;gap:5px;color:var(--ink-3)}
.dd-list{flex:1;overflow-y:auto;padding:0 14px 12px}
.dd-empty{padding:18px;color:var(--ink-3);font-size:13px;text-align:center}
.dd-doc-row{border:1px solid var(--line);border-radius:var(--r-lg);margin-bottom:8px;overflow:hidden}
.dd-doc-main{display:flex;align-items:center;gap:10px;padding:11px 13px;cursor:pointer}
.dd-doc-main:hover{background:var(--hover)}
.dd-doc-ico{font-size:20px;flex:0 0 auto}
.dd-doc-name{font-weight:600;font-size:13px}
.dd-doc-meta{font-size:11.5px;color:var(--ink-3)}
.dd-doc-actions{display:flex;gap:6px;padding:8px 13px;border-top:1px solid var(--line);background:var(--surface-2);flex-wrap:wrap}
.dd-linked{padding:12px 14px 18px;border-top:1px solid var(--line);flex:0 0 auto;background:var(--surface-2)}
.dd-section-l{font-size:10.5px;text-transform:uppercase;letter-spacing:.06em;color:var(--ink-faint);font-weight:700}
.ext-overlay{position:fixed;inset:0;background:oklch(0.2 0.01 265 / 0.5);z-index:600;display:flex;align-items:center;justify-content:center;padding:20px}
.ext-modal{background:var(--surface);border-radius:var(--r-xl);box-shadow:var(--shadow-lg);width:100%;max-width:900px;max-height:90vh;display:flex;flex-direction:column;overflow:hidden}
.ext-head{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--line);flex:0 0 auto}
.ext-body{display:grid;grid-template-columns:1fr 1fr;flex:1;overflow:hidden}
.ext-pdf-col{border-right:1px solid var(--line);padding:14px;overflow-y:auto;display:flex;flex-direction:column;gap:8px}
.ext-fields-col{padding:14px 16px;overflow-y:auto}
.ext-row{display:flex;align-items:center;gap:8px;padding:9px 10px;border:1px solid var(--line);border-radius:var(--r);flex-wrap:wrap}
.ext-row.validated{background:var(--good-soft);border-color:var(--good-line)}
.ext-field{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;color:var(--ink-faint);flex:0 0 110px}
.ext-input{flex:1;border:1px solid var(--line-2);border-radius:5px;padding:5px 8px;font-family:var(--mono);font-size:12.5px;color:var(--ink);min-width:80px;background:#fff}
.ext-input:read-only{background:transparent;border-color:transparent}
.ext-src{font-size:10px;color:var(--ink-faint)}
.cmt-row{padding:8px 0;border-bottom:1px solid var(--line);font-size:12.5px}
.cmt-row b{font-weight:700}
.cmt-input{flex:1;border:1px solid var(--line-2);border-radius:var(--r);padding:8px 10px;font-family:var(--sans);font-size:13px;outline:none}`;
    document.head.appendChild(s);
  }

  function openFor(opts) {
    close();
    injectStyles();
    const { entityType, entityId, entityName } = opts;
    const div = document.createElement('div');
    div.innerHTML = buildDrawer(entityType, entityId, entityName);
    document.body.appendChild(div.firstElementChild);
    _open = true;
    document.getElementById('ak-doc-drawer').addEventListener('click', e => {
      if (e.target.id === 'ak-doc-drawer') close();
    });
  }

  function openExtraction(docId, entityId, entityName) {
    const existing = document.getElementById('ak-ext-overlay');
    if (existing) existing.remove();
    const div = document.createElement('div');
    div.innerHTML = buildExtractionOverlay(docId, entityId, entityName);
    document.body.appendChild(div.firstElementChild);
  }

  function validateField(docId, index) {
    if (EXTRACTIONS[docId] && EXTRACTIONS[docId][index]) {
      EXTRACTIONS[docId][index].validated = true;
      EXTRACTIONS[docId][index].by = 'Arjun Mehta';
      AK && AK.toast('Field validated · propagating to entity profile');
      const overlay = document.getElementById('ak-ext-overlay');
      if (overlay) { overlay.remove(); }
    }
  }

  function close() {
    const el = document.getElementById('ak-doc-drawer');
    if (el) el.remove();
    _open = false;
  }

  function triggerUpload(entityId) {
    AK && AK.toast('Upload dialog opened — drag & drop or browse to select file');
  }

  function handleDrop(event, entityId, entityName) {
    event.preventDefault();
    const zone = event.currentTarget;
    zone.classList.remove('drag');
    const files = event.dataTransfer.files;
    if (files.length) AK && AK.toast(`Ingesting "${files[0].name}" — extraction queued`);
  }

  function addCrossLink(entityId) {
    AK && AK.toast('Cross-link dialog — search for document to link');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectStyles);
  else injectStyles();

  window.AKDocs = { openFor, close, openExtraction, validateField, triggerUpload, handleDrop, addCrossLink };
})();
