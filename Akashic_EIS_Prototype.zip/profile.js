/* Client 360 Profile — data + rendering */
(function(){
const $=s=>document.querySelector(s);

/* ---------- A · TIMELINE ---------- */
const tlEvents=[
  {x:2,  t:'MSA signed',      type:'contract', dir:'up'},
  {x:9,  t:'SOW-01 Atlas',    type:'project',  dir:'dn'},
  {x:18, t:'Go-live Phase 1', type:'project',  dir:'up'},
  {x:27, t:'₹4.2 Cr invoice', type:'invoice',  dir:'dn'},
  {x:35, t:'Renewal 2022',    type:'contract', dir:'up'},
  {x:44, t:'QBR · expansion', type:'touch',    dir:'dn'},
  {x:53, t:'SOW-04 Orion',    type:'project',  dir:'up'},
  {x:62, t:'Addendum signed', type:'contract', dir:'dn'},
  {x:70, t:'₹3.8 Cr payment', type:'invoice',  dir:'up'},
  {x:78, t:'Escalation MoM',  type:'touch',    dir:'dn'},
  {x:88, t:'Orion deadline',  type:'future',   dir:'up'},
  {x:96, t:'Renewal due ⚑',   type:'future',   dir:'dn'},
];
const tcolor={contract:'var(--accent)',project:'var(--good)',invoice:'var(--composite)',touch:'var(--ink-faint)',future:'var(--warn)'};
$('#timeline').innerHTML='<div class="tl-now"></div>'+tlEvents.map(e=>`
  <div class="tl-ev ${e.dir} ${e.type==='future'?'future':''}" style="left:${e.x}%" title="${e.t}" onclick="AK.toast('Event: ${e.t}')">
    <span class="lbl">${e.t}</span>
    <span class="stem"></span>
    <span class="pt" style="background:${tcolor[e.type]}"></span>
  </div>`).join('');
$('#tlscrub').addEventListener('input',function(){
  document.querySelector('.tl-now').style.left=this.value+'%';
});

/* ---------- B · CONTRACTS ---------- */
const conf=(lvl,v)=>lvl==='verified'?`<span class="conf verified">✓</span>`:`<span class="conf ${lvl}"><span class="cbar"><i style="width:${lvl==='lo'?68:lvl==='md'?82:93}%"></i></span>${v}</span>`;
const contracts=[
  {type:'MSA',sv:'Master agreement · all services',val:'—',vc:'verified',s:'18 Mar 2019',e:'22 Jun 2026',ec:'lo',ev:'0.71',auto:'No',auc:'verified',st:'b-renewal',stl:'Renewal'},
  {type:'SOW-04',sv:'Orion commerce rollout',val:'₹9.6 Cr',vc:'verified',s:'02 Jan 2025',e:'30 Sep 2026',ec:'verified',ev:'✓',auto:'No',auc:'md',st:'b-active',stl:'Active'},
  {type:'SOW-03',sv:'Managed support · platform',val:'₹4.1 Cr/yr',vc:'md',vv:'0.84',s:'01 Apr 2024',e:'31 Mar 2027',ec:'verified',ev:'✓',auto:'Yes',auc:'verified',st:'b-active',stl:'Active'},
  {type:'Addendum A2',sv:'Data residency clause',val:'—',vc:'verified',s:'15 Nov 2024',e:'—',ec:'verified',ev:'✓',auto:'—',auc:'verified',st:'b-active',stl:'Active'},
  {type:'SOW-02',sv:'Atlas migration (closed)',val:'₹6.2 Cr',vc:'verified',s:'10 Feb 2022',e:'20 Aug 2023',ec:'verified',ev:'✓',auto:'No',auc:'verified',st:'b-churned',stl:'Expired'},
];
$('#contract-tbl tbody').innerHTML=contracts.map(c=>`<tr>
  <td><span class="cell-strong mono">${c.type}</span></td>
  <td class="cell-sub" style="color:var(--ink-2)">${c.sv}</td>
  <td class="r cell-mono cell-strong">${c.val}</td>
  <td class="cell-mono">${c.s}</td>
  <td><div class="flex items-center gap-8"><span class="cell-mono">${c.e}</span>${c.ec==='verified'?'':conf(c.ec,c.ev)}</div></td>
  <td>${c.auto==='Yes'?'<span class="badge b-active" style="padding:1px 8px"><span class="bd"></span>Yes</span>':`<span class="muted">${c.auto}</span>`}</td>
  <td><span class="badge ${c.st}"><span class="bd"></span>${c.stl}</span></td>
  <td><a class="btn xs" onclick="AK.toast('Opening source document with extraction overlay')">View source</a></td>
</tr>`).join('');

/* ---------- C · REVENUE CHART + WATERFALL ---------- */
const rev=[78,82,88,72,95,110,86,120,140,98,132,150,118,160,142,175,138,168,190,205,178,212,196,224];
const ms=[3,8,13,17,21];
const maxR=Math.max(...rev);
let bars='';
rev.forEach((v,i)=>{ bars+=`<div class="rc-bar ${ms.includes(i)?'ms':''}" style="height:${(v/maxR*100).toFixed(1)}%" title="₹${v} L"></div>`; });
// ltv cumulative line as svg
let cum=0; const cumPts=rev.map((v,i)=>{cum+=v; return cum;});
const cmax=Math.max(...cumPts);
const W=100,H=160;
const path=cumPts.map((c,i)=>`${(i/(rev.length-1)*W).toFixed(2)},${(H-(c/cmax)*(H-20)-6).toFixed(2)}`).join(' ');
$('#revchart').innerHTML=bars+`<svg class="ltv-line" viewBox="0 0 100 160" preserveAspectRatio="none"><polyline points="${path}" fill="none" stroke="var(--composite)" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`;

const wf=[['Booked','₹68.4 Cr',100,'var(--accent)'],['Billed','₹58.9 Cr',86,'var(--composite)'],['Collected','₹52.1 Cr',76,'var(--good)']];
$('#waterfall').innerHTML=wf.map(w=>`<div class="wf-col"><div class="wf-v">${w[1]}</div><div class="wf-bar" style="height:${w[2]}%;background:${w[3]}"></div><div class="wf-l">${w[0]}</div></div>`).join('');

/* ---------- D · PROJECTS ---------- */
const projects=[
  {n:'Orion Rollout',st:'crit',stl:'At-Risk',budget:86,margin:'14%',mc:'warn-text',days:'11 days behind',lead:'Vikram Rao',ms:'7 / 11'},
  {n:'Helix Managed Support',st:'good',stl:'On-track',budget:54,margin:'31%',mc:'good-text',days:'On schedule',lead:'Sneha Pillai',ms:'continuous'},
  {n:'Atlas Data Sync',st:'warn',stl:'Watch',budget:72,margin:'22%',mc:'',days:'4 days behind',lead:'Imran Q.',ms:'9 / 12'},
  {n:'Insights Dashboard',st:'good',stl:'On-track',budget:41,margin:'34%',mc:'good-text',days:'Ahead',lead:'Sneha Pillai',ms:'3 / 6'},
];
$('#projects').innerHTML=projects.map(p=>`<div class="proj">
  <div class="proj-top"><span class="hdot ${p.st}"></span><a href="ProjectProfile.html" class="proj-name accent-text">${p.n}</a><span class="badge ${p.st==='crit'?'b-risk':p.st==='warn'?'b-renewal':'b-active'}" style="margin-left:auto;padding:1px 8px"><span class="bd"></span>${p.stl}</span></div>
  <div class="proj-grid">
    <div><div class="pg-l">Budget used</div><div class="pg-v ${p.budget>80?'crit-text':''}">${p.budget}%</div><div class="meter ${p.budget>80?'crit':p.budget>65?'warn':'good'}" style="margin-top:4px"><i style="width:${p.budget}%"></i></div></div>
    <div><div class="pg-l">Margin</div><div class="pg-v ${p.mc}">${p.margin}</div></div>
    <div><div class="pg-l">Milestones</div><div class="pg-v">${p.ms}</div></div>
  </div>
  <div class="proj-res"><span class="avatar sm gray" style="width:18px;height:18px;font-size:8px">${p.lead.split(' ').map(x=>x[0]).join('')}</span>Lead: ${p.lead} · ${p.days}</div>
</div>`).join('');

/* ---------- E · EMPLOYEE EXPOSURE ---------- */
const exposure=[
  {n:'Vikram Rao',r:'Lead Architect',util:96,risk:'crit',ten:'4.2 yrs',spof:true},
  {n:'Sneha Pillai',r:'Delivery Manager',util:88,risk:'good',ten:'2.1 yrs',spof:false},
  {n:'Imran Qureshi',r:'Sr. Data Engineer',util:92,risk:'warn',ten:'1.8 yrs',spof:false},
  {n:'Lena Fischer',r:'Onsite Coordinator (Dallas)',util:80,risk:'good',ten:'3.0 yrs',spof:false},
  {n:'Arjun Bhat',r:'QA Lead',util:74,risk:'good',ten:'1.1 yrs',spof:false},
];
$('#exposure').innerHTML=exposure.map(e=>`<div class="exp-row">
  <a href="EmployeeProfile.html"><span class="avatar sm gray">${e.n.split(' ').map(x=>x[0]).join('')}</span></a>
  <div style="flex:1;min-width:0"><div class="flex items-center gap-6"><a href="EmployeeProfile.html" class="exp-name accent-text">${e.n}</a>${e.spof?'<span class="spof" style="margin-left:4px">⚑ SPOF · 64%</span>':''}</div><div class="exp-role">${e.r} · ${e.ten} on account</div></div>
  <div class="exp-util"><div class="flex justify-between fs-11 faint" style="margin-bottom:3px"><span>util</span><b style="color:var(--ink-2)">${e.util}%</b></div><div class="meter ${e.util>90?'crit':e.util>80?'warn':'good'}"><i style="width:${e.util}%"></i></div></div>
  <span class="hdot ${e.risk}" title="Attrition risk"></span>
</div>`).join('');

/* ---------- F · GEO + TXN ---------- */
const geo=[['United States','#2563a8',52,'₹7.4 Cr'],['India (delivery)','#3a7a55',31,'₹4.4 Cr'],['Germany','#5a4f9e',17,'₹2.4 Cr']];
$('#geo').innerHTML=geo.map(g=>`<div class="geo-row"><span class="geo-name">${g[0]}</span><div class="geo-bar"><i style="width:${g[2]}%;background:${g[1]}"></i></div><span class="geo-pct">${g[3]} · ${g[2]}%</span></div>`).join('');
const txns=[
  ['28 May 26','INV-2026-0412','SOW-04 · Orion M7','₹1.20 Cr','b-renewal','Outstanding'],
  ['12 May 26','INV-2026-0388','SOW-03 · Support Q1','₹1.03 Cr','b-active','Paid'],
  ['30 Apr 26','INV-2026-0351','SOW-04 · Orion M6','₹0.96 Cr','b-active','Paid'],
  ['14 Mar 26','INV-2026-0309','SOW-03 · Support','₹1.03 Cr','b-risk','Overdue 90+'],
  ['28 Feb 26','INV-2026-0276','SOW-04 · Orion M5','₹1.10 Cr','b-active','Paid'],
];
$('#txn tbody').innerHTML=txns.map(t=>`<tr><td class="cell-mono">${t[0]}</td><td class="cell-mono accent-text">${t[1]}</td><td class="cell-sub" style="color:var(--ink-2)">${t[2]}</td><td class="r cell-mono cell-strong">${t[3]}</td><td><span class="badge ${t[4]}" style="padding:1px 8px"><span class="bd"></span>${t[5]}</span></td></tr>`).join('');

/* ---------- G · DOCUMENTS ---------- */
const docs=[
  ['Meridian_MSA_2019.pdf','MSA','✓ Ingested','lo','0.71','pending'],
  ['SOW-04_Orion.pdf','SOW','✓ Ingested','verified','✓','done'],
  ['Addendum_A2_DataResidency.pdf','Addendum','✓ Ingested','md','0.84','pending'],
  ['QBR_Apr2026_MoM.docx','MoM','✓ Ingested','verified','✓','done'],
  ['Renewal_Intent_email.eml','Email','⏳ Processing','—','—','queue'],
];
$('#docs tbody').innerHTML=docs.map(d=>{
  const ext=d[3]==='verified'?'<span class="conf verified">✓ extracted</span>':d[3]==='—'?'<span class="muted">—</span>':`<span class="conf ${d[3]}"><span class="cbar"><i style="width:${d[3]==='lo'?71:84}%"></i></span>${d[4]}</span>`;
  const val=d[5]==='done'?'<span class="doc-status good-text">✓ Validated · K. Iyer</span>':d[5]==='pending'?'<span class="doc-status warn-text">⚑ Needs review</span>':'<span class="doc-status muted">In queue</span>';
  return `<tr><td><span class="cell-strong mono fs-12">${d[0]}</span></td><td><span class="tag">${d[1]}</span></td><td class="cell-sub">${d[2]}</td><td>${ext}</td><td>${val}</td>
  <td><div class="flex gap-6">${AK.icon?`<button class="qbtn" style="width:26px;height:26px" title="View" onclick="AK.toast('Opening extraction overlay')">${AK.icon('eye')}</button><button class="qbtn" style="width:26px;height:26px" title="Download" onclick="AK.toast('Download started')">${AK.icon('download')}</button>`:''}</div></td></tr>`;
}).join('');
})();
