/* employee-profile.js — rendering for Vikram Rao 360 */
(function () {
  /* ---- A: Career Timeline ---- */
  const tcolor = { career:'var(--accent)', deploy:'var(--good)', comp:'var(--composite)', future:'var(--warn)' };
  const tlEvents = [
    { x:2,  t:'Joined Nexora', type:'career', dir:'up' },
    { x:10, t:'Sr. Engineer →', type:'career', dir:'dn' },
    { x:18, t:'Cobalt Data project', type:'deploy', dir:'up' },
    { x:26, t:'Hike Apr 2022', type:'comp', dir:'dn' },
    { x:34, t:'Promoted: Principal', type:'career', dir:'up' },
    { x:42, t:'Indus Cloud deploy', type:'deploy', dir:'dn' },
    { x:50, t:'Hike Apr 2024', type:'comp', dir:'up' },
    { x:60, t:'Orion assigned', type:'deploy', dir:'dn' },
    { x:68, t:'Perf review: Strong', type:'career', dir:'up' },
    { x:78, t:'3 recruiter contacts', type:'future', dir:'dn' },
    { x:88, t:'Review due Dec 26', type:'future', dir:'up' },
    { x:96, t:'Flight risk ⚑', type:'future', dir:'dn' },
  ];
  const tl = document.getElementById('emp-timeline');
  if (tl) tl.innerHTML = '<div class="tl-now" style="left:72%"></div>' + tlEvents.map(e =>
    `<div class="tl-ev ${e.dir} ${e.type==='future'?'future':''}" style="left:${e.x}%" title="${e.t}">
      <span class="lbl">${e.t}</span><span class="stem"></span>
      <span class="pt" style="background:${tcolor[e.type]}"></span>
    </div>`).join('');

  /* ---- B: Deployments ---- */
  const deployments = [
    { account:'Cobalt Energy',    project:'Data Eng setup', from:'Aug 2020', to:'Jan 2021', util:92, margin:'38%', status:'done' },
    { account:'Indus Pharma',     project:'Cloud migration', from:'Feb 2021', to:'Jun 2022', util:88, margin:'34%', status:'done' },
    { account:'Hanseatic Bank',   project:'Core Banking', from:'Jul 2022', to:'Sep 2023', util:90, margin:'29%', status:'done' },
    { account:'[Bench]',          project:'—', from:'Oct 2023', to:'Dec 2023', util:0, margin:'—', status:'bench' },
    { account:'Meridian Retail',  project:'Orion Rollout', from:'Jan 2025', to:'Present', util:96, margin:'14%', status:'active' },
    { account:'Cobalt Energy',    project:'Data Lake (partial)', from:'Mar 2025', to:'Present', util:32, margin:'34%', status:'active' },
  ];
  const dp = document.getElementById('deployments');
  if (dp) dp.innerHTML = deployments.map(d => `<div class="dep-row ${d.status==='bench'?'bench-row-s':''}">
    <div class="flex items-center gap-8">
      <span class="hdot ${d.status==='active'?'good':d.status==='bench'?'neutral':'good'}" style="width:7px;height:7px;box-shadow:none"></span>
      <div style="flex:1;min-width:0">
        <div class="flex items-center justify-between"><b class="fs-13">${d.account}</b><span class="mono fs-11 faint">${d.from} → ${d.to}</span></div>
        <div class="exp-role">${d.project}</div>
      </div>
    </div>
    <div class="flex items-center gap-10 mt-6" style="margin-left:15px">
      <div style="flex:0 0 120px"><div class="flex justify-between fs-11 faint mb-3"><span>util</span><b style="color:var(--ink-2)">${d.util}%</b></div>
        <div class="meter ${d.util>90?'crit':d.util>70?'warn':'good'}"><i style="width:${d.util}%"></i></div></div>
      <span class="fs-12 muted">Margin: <b>${d.margin}</b></span>
    </div>
  </div>`).join('');

  /* ---- C: Value grid ---- */
  const valgrid = document.getElementById('valgrid');
  if (valgrid) valgrid.innerHTML = `
    <div class="val-row"><div class="val-bar-wrap">
      <div class="val-label">Revenue / yr</div>
      <div class="val-bar" style="width:100%;background:var(--accent)"></div>
      <div class="val-num" data-prov='{"src":"PSA + billing","q":"revenue_attr WHERE emp=E01","conf":0.91,"refresh":"daily"}'>₹1.84 Cr</div>
    </div></div>
    <div class="val-row"><div class="val-bar-wrap">
      <div class="val-label">Margin contrib.</div>
      <div class="val-bar" style="width:82%;background:var(--good)"></div>
      <div class="val-num good-text">₹62 L</div>
    </div></div>
    <div class="val-row"><div class="val-bar-wrap">
      <div class="val-label">Cost (CTC)</div>
      <div class="val-bar" style="width:48%;background:var(--composite)"></div>
      <div class="val-num muted">₹38 L</div>
    </div></div>
    <div class="val-row"><div class="val-bar-wrap">
      <div class="val-label">Realization rate</div>
      <div class="val-bar" style="width:88%;background:var(--ink-3)"></div>
      <div class="val-num">88%</div>
    </div></div>`;

  /* ---- D: Skills ---- */
  const skills = [
    { name:'Apache Spark / PySpark', level:5, demand:'high', cert:'Databricks Certified' },
    { name:'Snowflake Data Cloud', level:5, demand:'high', cert:'Snowflake SnowPro Core' },
    { name:'AWS Data Services', level:4, demand:'high', cert:'AWS SA Associate' },
    { name:'dbt (data build tool)', level:4, demand:'med', cert:null },
    { name:'LLM / GenAI Ops', level:2, demand:'critical', cert:null },
    { name:'Solution Architecture', level:5, demand:'med', cert:null },
  ];
  const demandColor = { high:'var(--warn)', critical:'var(--critical)', med:'var(--good)', low:'var(--ink-faint)' };
  const sd = document.getElementById('skills');
  if (sd) sd.innerHTML = skills.map(s => `<div class="skill-row">
    <div class="flex items-center justify-between mb-4">
      <b class="fs-13">${s.name}</b>
      ${s.cert ? `<span class="tag mono" style="font-size:9.5px">✓ ${s.cert}</span>` : ''}
    </div>
    <div class="flex items-center gap-10">
      <div style="display:flex;gap:3px">${[1,2,3,4,5].map(i=>`<span style="width:12px;height:12px;border-radius:3px;background:${i<=s.level?'var(--accent)':'var(--surface-3)'}"></span>`).join('')}</div>
      <span class="fs-11" style="color:${demandColor[s.demand]}">Pipeline demand: ${s.demand}</span>
    </div>
  </div>`).join('');

  /* ---- E: Risk drivers ---- */
  const drivers = [
    { label:'Compensation 28% below market', weight:34, severity:'crit' },
    { label:'No promotion in 18 months', weight:24, severity:'warn' },
    { label:'3 documented recruiter contacts', weight:22, severity:'warn' },
    { label:'Overutilized 96% — burnout signal', weight:18, severity:'warn' },
  ];
  const rd = document.getElementById('riskdrivers');
  if (rd) rd.innerHTML = drivers.map(d => `<div class="risk-drv">
    <div class="flex items-center justify-between mb-4"><span class="fs-13">${d.label}</span><span class="mono ${d.severity==='crit'?'crit-text':'warn-text'} strong fs-12">${d.weight}%</span></div>
    <div class="meter ${d.severity}"><i style="width:${d.weight*2.5}%"></i></div>
  </div>`).join('');

  const spof = document.getElementById('spof-exp');
  if (spof) spof.innerHTML = `<div class="flex items-center gap-10 p-8" style="background:var(--critical-soft);border:1px solid var(--critical-line);border-radius:8px;padding:10px 12px">
    <span class="hdot crit"></span>
    <div><a href="ClientProfile.html" class="strong accent-text">Meridian Retail Group</a>
      <div class="exp-role">64% of Orion delivery — ₹14.2 Cr account. No shadow. Immediate risk.</div></div>
    <span class="crit-text mono strong" style="margin-left:auto">₹14.2 Cr</span>
  </div>
  <div class="flex items-center gap-10" style="padding:8px;border:1px solid var(--line);border-radius:8px">
    <span class="hdot warn"></span>
    <div><a href="ClientProfile.html" class="strong accent-text">Cobalt Energy</a>
      <div class="exp-role">32% allocation — secondary risk. Can be covered by I. Qureshi.</div></div>
    <span class="warn-text mono strong" style="margin-left:auto">₹9.3 Cr</span>
  </div>`;

  const levers = document.getElementById('levers');
  if (levers) levers.innerHTML = [
    { l:'Compensation review', impact:'−22pt risk', cost:'₹10 L', type:'primary', action:'APPROVE_HIKE' },
    { l:'Promotion to Distinguished Engineer', impact:'−18pt risk', cost:'Structural', type:'', action:'RETENTION_ACTION' },
    { l:'Assign shadow architect', impact:'Reduces SPOF', cost:'₹8 L ramp', type:'', action:'FLAG_SUCCESSION' },
    { l:'Reduce allocation to 80%', impact:'−12pt burnout', cost:'Revenue impact', type:'', action:'REDEPLOY' },
  ].map(l => `<div class="flex items-center gap-10" style="padding:8px 10px;border:1px solid var(--line);border-radius:8px">
    <div style="flex:1"><b class="fs-13">${l.l}</b><div class="exp-role">${l.impact} · ${l.cost}</div></div>
    <button class="btn xs ${l.type==='primary'?'primary':''}" onclick="AKActions.compose({type:'${l.action}',entityType:'employee',entityId:'E01',entityName:'Vikram Rao',prefill:{employee:'Vikram Rao',lever:'${l.l}'}})">Action</button>
  </div>`).join('');

  /* ---- F: Engagement ---- */
  const ooos = document.getElementById('ooos');
  if (ooos) ooos.innerHTML = [
    { date:'28 May 2026', by:'Karthik Menon', note:'Discussed workload. Vikram flagged interest in architecture leadership role. Follow-up scheduled.' },
    { date:'12 Apr 2026', by:'Priya Nair', note:'Client appreciation shared. Flagged comp concern informally.' },
    { date:'01 Mar 2026', by:'Karthik Menon', note:'Mid-year check-in. Engagement moderate. No escalation yet.' },
  ].map(o => `<div class="ooo-row"><div class="flex items-center gap-8 mb-4"><b class="fs-12 mono">${o.date}</b><span class="muted">— ${o.by}</span></div><div class="fs-12 muted">${o.note}</div></div>`).join('');

  const ed = document.getElementById('emp-docs');
  if (ed) ed.innerHTML = [
    { name:'Offer_Letter_2020.pdf', type:'Offer', validated:true },
    { name:'Appraisal_FY25.pdf',    type:'Review', validated:true },
    { name:'Comp_Letter_Apr24.pdf', type:'Comp', validated:true },
  ].map(d => `<div class="dd-doc-row"><div class="dd-doc-main" onclick="AK.toast('${d.name} — RBAC: CEO only')">
    <span class="dd-doc-ico">📄</span>
    <div><div class="dd-doc-name">${d.name}</div><div class="dd-doc-meta">${d.type}</div></div>
    <span class="conf verified">✓</span>
  </div></div>`).join('');
})();
