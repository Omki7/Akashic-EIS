/* ProjectProfile.js — rendering for Orion Commerce Rollout 360 */
(function () {
  /* ---- A: Timeline ---- */
  const tcolor = { sow:'var(--accent)', ms:'var(--good)', inv:'var(--composite)', cr:'var(--critical)', future:'var(--warn)' };
  const tlEvents = [
    { x:4,  t:'SOW-04 signed',     type:'sow',    dir:'up' },
    { x:12, t:'Kickoff complete',  type:'ms',     dir:'dn' },
    { x:21, t:'M1: Architecture',  type:'ms',     dir:'up' },
    { x:29, t:'CR-01 approved',    type:'cr',     dir:'dn' },
    { x:38, t:'M3: Frontend beta', type:'ms',     dir:'up' },
    { x:46, t:'INV-0276 raised',   type:'inv',    dir:'dn' },
    { x:54, t:'M5: Integrations',  type:'ms',     dir:'up' },
    { x:62, t:'CR-02 scope add',   type:'cr',     dir:'dn' },
    { x:71, t:'INV-0412 raised',   type:'inv',    dir:'up' },
    { x:79, t:'M7: Delayed ⚑',     type:'future', dir:'dn' },
    { x:88, t:'M8 due',            type:'future', dir:'up' },
    { x:96, t:'Go-live Sep 2026',  type:'future', dir:'dn' },
  ];
  const tl = document.getElementById('p-timeline');
  if (tl) tl.innerHTML = '<div class="tl-now" style="left:74%"></div>' + tlEvents.map(e =>
    `<div class="tl-ev ${e.dir} ${e.type === 'future' ? 'future' : ''}" style="left:${e.x}%" title="${e.t}" onclick="AK.toast('${e.t}')">
      <span class="lbl">${e.t}</span><span class="stem"></span>
      <span class="pt" style="background:${tcolor[e.type]}"></span>
    </div>`).join('');

  /* ---- B: Milestones table ---- */
  const milestones = [
    ['M1','Architecture design','₹60 L','Jan 2025','done','paid'],
    ['M2','UI/UX sign-off','₹58 L','Mar 2025','done','paid'],
    ['M3','Frontend beta','₹72 L','May 2025','done','paid'],
    ['M4','Backend integration','₹88 L','Aug 2025','done','paid'],
    ['M5','Integration test','₹74 L','Oct 2025','done','paid'],
    ['M6','UAT sign-off','₹96 L','Jan 2026','done','paid'],
    ['M7','Performance & go/no-go','₹1.1 Cr','Apr 2026','delayed','outstanding'],
    ['M8','Pre-launch hardening','₹96 L','Jun 2026','upcoming','unbilled'],
    ['M9','Go-live','₹1.1 Cr','Sep 2026','upcoming','unbilled'],
    ['M10','Hypercare month 1','₹48 L','Oct 2026','upcoming','unbilled'],
    ['M11','Project closure','₹28 L','Nov 2026','upcoming','unbilled'],
  ];
  const mt = document.getElementById('milestones');
  if (mt) mt.innerHTML = `<thead><tr><th>MS</th><th>Description</th><th class="r">Value</th><th>Due</th><th>Status</th><th>Invoice</th></tr></thead>
    <tbody>${milestones.map(m => {
      const sc = m[4]==='done'?'b-active':m[4]==='delayed'?'b-risk':'b-prospect';
      const ic = m[5]==='paid'?'b-active':m[5]==='outstanding'?'b-renewal':m[5]==='unbilled'?'b-prospect':'b-risk';
      return `<tr><td class="cell-mono strong">${m[0]}</td><td class="cell-sub" style="color:var(--ink-2)">${m[1]}</td>
        <td class="r cell-mono">${m[2]}</td><td class="cell-mono fs-12">${m[3]}</td>
        <td><span class="badge ${sc}" style="padding:0 8px"><span class="bd"></span>${m[4]}</span></td>
        <td><span class="badge ${ic}" style="padding:0 8px"><span class="bd"></span>${m[5]}</span>
          ${m[5]==='outstanding'||m[5]==='unbilled'?`<button class="btn xs" style="margin-left:4px" onclick="AKActions.compose({type:'RAISE_INVOICE',entityType:'project',entityId:'P01',entityName:'Orion Commerce Rollout',prefill:{milestone:'${m[0]}',amount:'${m[2]}'}})">Raise</button>`:''}
        </td></tr>`;
    }).join('')}</tbody>`;

  /* ---- B: Change requests ---- */
  const crs = [
    { id:'CR-01', title:'Add loyalty module', impact:'+₹22 L', status:'approved', date:'Mar 2025' },
    { id:'CR-02', title:'Expand data residency scope', impact:'+₹16 L', status:'approved', date:'Nov 2025' },
    { id:'CR-03', title:'Additional UAT cycles ×2', impact:'+₹18 L', status:'pending', date:'May 2026' },
  ];
  const crd = document.getElementById('crs');
  if (crd) crd.innerHTML = crs.map(c => `<div class="proj" style="padding:10px 12px">
    <div class="flex items-center gap-8"><b class="mono fs-12">${c.id}</b>
      <span class="badge ${c.status==='approved'?'b-active':'b-renewal'}" style="padding:0 7px"><span class="bd"></span>${c.status}</span>
      <span class="mono fs-11 faint" style="margin-left:auto">${c.date}</span></div>
    <div class="fs-13 mt-4">${c.title}</div>
    <div class="flex items-center gap-8 mt-4"><b class="good-text mono">${c.impact}</b>
      ${c.status==='pending'?`<button class="btn xs primary" onclick="AKActions.compose({type:'APPROVE_CR',entityType:'project',entityId:'P01',entityName:'Orion Commerce Rollout',prefill:{crTitle:'${c.title}',impact:'${c.impact}'}})">Approve</button>`:''}
    </div>
  </div>`).join('');

  /* ---- C: Burn-down chart ---- */
  const planned = [0, 1.6, 3.2, 4.8, 6.4, 7.6, 8.8, 9.6, 9.6];
  const actual  = [0, 1.5, 3.4, 5.1, 6.5, 7.2, 8.0, 8.26];
  const eac     = [null,null,null,null,null,null,null, 8.26, 8.8, 9.4, 10.22];
  const W = 100, H = 120, MAX = 10.6;
  function line(pts, color, dash) {
    const valid = pts.map((v,i) => v !== null ? `${(i/(pts.length-1)*W).toFixed(1)},${(H - v/MAX*H).toFixed(1)}` : null).filter(Boolean);
    const start = pts.findIndex(v => v !== null);
    const startPts = pts.slice(start).filter(v => v !== null).map((v,i) => `${((i+start)/(pts.length-1)*W).toFixed(1)},${(H - v/MAX*H).toFixed(1)}`);
    return `<polyline points="${startPts.join(' ')}" fill="none" stroke="${color}" stroke-width="${dash?1.4:1.8}" stroke-dasharray="${dash?'4,3':''}" vector-effect="non-scaling-stroke"/>`;
  }
  const bd = document.getElementById('burndown');
  if (bd) bd.innerHTML = `<svg viewBox="0 0 100 120" preserveAspectRatio="none" style="width:100%;height:140px;border-bottom:1px solid var(--line-2);border-left:1px solid var(--line-2)">
    ${line(planned,'var(--accent)',true)}${line(actual,'var(--critical)',false)}${line(eac,'var(--warn)',true)}</svg>`;

  /* ---- D: Team ---- */
  const team = [
    { name:'Vikram Rao',     role:'Lead Architect', pct:64, risk:'crit', spof:true,  since:'Jan 2025', eid:'E01' },
    { name:'Arjun Bhat',     role:'QA Lead',        pct:30, risk:'good', spof:false, since:'Jan 2025', eid:'E08' },
    { name:'Priya Sharma',   role:'Frontend Dev',   pct:60, risk:'good', spof:false, since:'Feb 2026', eid:'E10' },
    { name:'Kavya Sharma',   role:'Business Analyst',pct:40,risk:'good', spof:false, since:'Jan 2025', eid:'E09' },
  ];
  const td = document.getElementById('team');
  if (td) td.innerHTML = team.map(t => `<div class="exp-row">
    <a href="EmployeeProfile.html"><span class="avatar sm gray">${t.name.split(' ').map(x=>x[0]).join('')}</span></a>
    <div style="flex:1;min-width:0">
      <div class="flex items-center gap-6">
        <a href="EmployeeProfile.html" class="exp-name accent-text">${t.name}</a>
        ${t.spof ? '<span class="spof">⚑ SPOF</span>' : ''}
      </div>
      <div class="exp-role">${t.role} · ${t.pct}% alloc · since ${t.since}</div>
    </div>
    <div class="exp-util"><div class="flex justify-between fs-11 faint mb-4"><span>alloc</span><b style="color:var(--ink-2)">${t.pct}%</b></div>
      <div class="meter ${t.risk}"><i style="width:${t.pct}%"></i></div></div>
    <span class="hdot ${t.risk}"></span>
    <button class="btn xs" onclick="AKActions.compose({type:'FLAG_SUCCESSION',entityType:'employee',entityId:'${t.eid}',entityName:'${t.name}'})">Plan shadow</button>
  </div>`).join('');

  /* ---- E: Risks ---- */
  const risks = [
    { severity:'crit', title:'Key-person dependency', desc:'Vikram Rao is sole architect. Exit = delivery halt.' },
    { severity:'warn', title:'Scope creep unpriced',  desc:'CR-03 ×2 UAT cycles pending approval — ₹18 L risk.' },
    { severity:'warn', title:'Client UAT delays',     desc:'M7 sign-off held by client. Nexora impact = SLA breach.' },
  ];
  const rd = document.getElementById('risks');
  if (rd) rd.innerHTML = risks.map(r => `<div class="flex items-start gap-9 p-8" style="padding:8px;border:1px solid var(--line);border-radius:8px">
    <span class="hdot ${r.severity}" style="margin-top:3px;flex:0 0 auto"></span>
    <div><b class="fs-13">${r.title}</b><div class="exp-role mt-2">${r.desc}</div></div>
  </div>`).join('');
})();
